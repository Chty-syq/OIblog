#include <iostream>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;
 
#define N 1000050
#define M 26
#define ll long long

int sun[N][M],h[N],suf[N],Cnt[N],fa[N],rf[N],cha[N],n,m,st;
int fi[N],ne[N],_fi[N],_ne[N];
ll ans; char ch[N];
 
void GetString()
 {
    scanf("%s", ch + 1);
    int Now = 1, len = strlen(ch + 1);
    for (int i = 1; i <= len; i++)
     {
        int l = ch[i] - 'a', k = sun[Now][l];
        if (!k)
         {
            sun[Now][l] = k = ++st;
            ne[st] = fi[i]; fi[h[st] = i] = st;
            _ne[st] = _fi[Now]; _fi[Now] = st;
            fa[st] = Now; cha[st] = l;
         }
        Now = k;
     }
    return;
 }
 
void Build()
 {
    suf[1] = 1;
    for (int j = fi[1]; j; j = ne[j]) suf[j] = 1;
    for (int i = 2; fi[i]; i ++)
     for (int j = fi[i]; j; j = ne[j])
      {
         suf[j] = suf[fa[j]];
         while (suf[j] != 1 && !sun[suf[j]][cha[j]])
           suf[j] = suf[suf[j]];
         if (sun[suf[j]][cha[j]])
           suf[j] = sun[suf[j]][cha[j]];
      }
    for (int i = N - 1; i; i--)
     for (int j = fi[i]; j; j = ne[j])
       Cnt[suf[j]] += ++Cnt[j];
    return;
 }
 
void DFS(int x, int y)
 {
    rf[y] = x;
    if (suf[x] != 1)
      ans += Cnt[rf[y - h[suf[x]]]] - 1;
    for (int i = _fi[x]; i; i = _ne[i])
      DFS(i, y + 1);
    return;
 }
 
int main()
 {
    freopen("string8.in","r",stdin);
    freopen("string8.out","w",stdout);

    cin >> n; cin >>n; st = fi[0] = 1;
    for (int i = 1; i <= n; i++) GetString();
    Build();DFS(1, 0);
    cout <<1LL * (st - 1) * (st - 1) - ans<<endl;
    return 0;
 }
