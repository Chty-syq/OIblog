#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <ctime>
#include <cstdlib>
#include <string>

using namespace std;

#define N 2000050
#define M 26

inline int Rand(int x)
 {return (1LL * rand() * rand() + 10079LL * rand()) % x;}
 
int n, Len, ch[N];

void Get0()
 {
 	int k = 100;
 	
 	freopen("string3.in","w",stdout);
 	puts("3"); puts("1"); n = 1000;
 	for (int i = 1; i <= n; i++) ch[i] = 0;
 	for (int i = 1; i <= k / 2; i++) ch[Rand(n - 5) + 1] = Rand(5);
 	for (int i = 1; i <= n; i++) putchar(ch[i] + 'a');
 	puts("");
 	fclose(stdout);
 	
 	freopen("string4.in","w",stdout);
 	puts("4"); puts("100");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - k) + k;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	freopen("string5.in","w",stdout);
 	puts("5"); puts("100");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - k) + k;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	freopen("string6.in","w",stdout);
 	puts("6"); puts("10");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < 10; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	return;
 }

void Get1()
 {
 	n = 54;
 	int k = 5;
 	freopen("string1.in","w",stdout);
 	puts("1"); puts("5");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	n = 59; k = 10;
 	freopen("string2.in","w",stdout);
 	puts("2"); puts("10");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 }

void Get2()
 {
 	n = 1000000;
 	int k = 5;
 	freopen("string15.in","w",stdout);
 	puts("15"); puts("5");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	n = 1009999; k = 10000;
 	freopen("string16.in","w",stdout);
 	puts("16"); puts("10000");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	n = 1000999; k = 1000;
 	freopen("string17.in","w",stdout);
 	puts("17"); puts("1000");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	n = 1009999; k = 10000;
 	freopen("string18.in","w",stdout);
 	puts("18"); puts("10000");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	n = 1000099; k = 100;
 	freopen("string19.in","w",stdout);
 	puts("19"); puts("100");
 	for (int i = 1; i <= n; i++) ch[i] = Rand(M);
 	for (int i = 1; i < k; i++)
 	  while (true)
 	   {
 	   	  int t = Rand(n - 2) + 2;
 	   	  if (ch[t - 1] < 0 || ch[t] < 0 || ch[t + 1] < 0) continue;
 	   	  ch[t] = -1; break;
	   }
 	for (int i = 1; i <= n; i++)
	 if (ch[i] != -1)
	   putchar(ch[i] + 'a'); else
	   puts("");
	puts("");
 	fclose(stdout);
 	
 	freopen("string20.in","w",stdout);
 	puts("20"); puts("1"); n = 1000000; k = 10000;
 	for (int i = 1; i <= n; i++) ch[i] = 5;
 	for (int i = 1; i <= k / 2; i++) ch[Rand(n - 5) + 1] = Rand(5);
 	for (int i = 1; i <= n; i++) putchar(ch[i] + 'a');
 	puts("");
 	fclose(stdout);
 }

void Get3()
 {
 	n = 1000; int k = 10;
 	freopen("string_Sample_3.in","w",stdout);
 	puts("0"); puts("100");
 	for (int i = 1; i <= n; i++)
 	 {
 	 	k = Rand(10) + 1;
 	 	for (int j = 1; j <= k; j ++) putchar(Rand(26) + 'a');
 	 	puts("");
     }
 	fclose(stdout);
 }

int main()
 {
 	srand(time(NULL));
 	//Get0();
	//Get1();
	//Get2();
	Get3();
 	return 0;
 }
