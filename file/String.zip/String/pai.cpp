#include<cstdio>
#include<cstring>
#include<queue>
#include<algorithm>
#include<iostream>
using namespace std;
const int maxn=300005;

int Cnt = false;

struct node{
  node* ch[26],*fail;
  int num,depth;
  node(int x,int d){depth=d;memset(ch,0,sizeof(ch));fail=0;num=x;}
}*root;int tot=0;
char str[35];
node* pos[maxn];
void Add(char *c){
  node* p=root;
  while(*c){
    int t=*c-'a';
    if(p->ch[t]==NULL){p->ch[t]=new node(++tot,p->depth+1);pos[tot]=p->ch[t]; Cnt ++;}
    p=p->ch[t];++c;
  }
}
long long f[maxn][32];
long long ans=0;
void getfail(){
  queue<node*> q;q.push(root);
  while(!q.empty()){
    node* x=q.front();q.pop();
    if(x!=root&&x->fail!=root)ans++;
    for(int i=0;i<26;++i){
      if(x->ch[i]){
    if(x==root)x->ch[i]->fail=root;
    else x->ch[i]->fail=x->fail->ch[i];
    q.push(x->ch[i]);
      }else{
    if(x==root)x->ch[i]=root;
    else x->ch[i]=x->fail->ch[i];
    f[x->ch[i]->num][1]++;
      }
    }
  }
}
int main(){
  freopen("string.in","r",stdin);
  int n;scanf("%d",&n);int maxlen=0;
  root=new node(0,0);pos[0]=root;
  for(int i=1;i<=n;++i){
    scanf("%s",str);int len=strlen(str);if(len>maxlen)maxlen=len;
    Add(str);
  }
  getfail();
  // for(int i=1;i<=tot;++i){
  //   for(int j=0;j<26;++j){
  //     if(pos[i]->ch[j]->num<=i){
  //     f[pos[i]->ch[j]->num][1]++;
  //     }
  //   }
  // }
  //printf("ans==%lld\n",ans);
  for(int k=1;k<=maxlen;++k){
    for(int i=1;i<=tot;++i){
      if(f[i][k]==0||pos[i]->depth<k)continue;
      for(int j=0;j<26;++j){
    f[pos[i]->ch[j]->num][k+1]+=f[i][k];
      }
      if(k<=pos[i]->depth)ans+=f[i][k];
      //printf("f[%d][%d]==%lld\n",i,k,f[i][k]);
    }
  }
  printf("%lld\n",ans);
  cout <<Cnt<<endl;
  return 0;
}
