// <make.cpp> - 04/02/16 19:52:55
// This file is created by XuYike's black technology automatically.
// Copyright (C) 2015 ChangJun High School, Inc.
// I don't know what this program is.

#include <iostream>
#include <cstdio>
#include <algorithm>
#include <ctime>
using namespace std;
const string N="y";
const int TSIZE=100;
const int NSIZE=100000;
const int MSIZE=100000;
int T,n,m;
int a[1000010];
int main(){
    freopen("seed","r",stdin);int x;cin>>x;srand(x);
    freopen("seed","w",stdout);cout<<rand();
    freopen((N+".in").c_str(),"w",stdout);
    T=2;
    //T=rand()%TSIZE+1;
    printf("%d\n",T);
    while(T--){
        n=50000;m=50000;
        printf("%d %d\n",n,m);
        for(int i=1;i<=n;i++)a[i]=i;
        for(int i=1;i<=100000;i++){
            int x=rand()%(n-1)+1;
            swap(a[x],a[x+1]);
        }
        for(int i=1;i<=n;i++)printf("%d ",a[i]);putchar('\n');
        while(m--){
            int len=rand()%(n>>1)+1;
            a[1]=rand()%(n-len*2+1)+1;a[2]=a[1]+len-1;
            a[3]=rand()%(n-a[2]-len+1)+a[2]+1;a[4]=a[3]+len-1;
            printf("%d %d %d %d\n",a[1],a[2],a[3],a[4]);
        }
    }
    return 0;
}
