// <y.cpp> - 07/06/17 15:35:21
// This file is created by XuYike's black technology automatically.
// Copyright (C) 2015 ChangJun High School, Inc.
// I don't know what this program is.

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;
typedef long long lol;
int gi(){
    int res=0,fh=1;char ch=getchar();
    while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
    if(ch=='-')fh=-1,ch=getchar();
    while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
    return fh*res;
}
const int N=100001;
const int MAXK=4000010;
const int INF=1e9;
const int MOD=1e9+7;
int qpow(int x,int y){
    int res=1;
    while(y){
        if(y&1)res=1ll*res*x%MOD;
        x=1ll*x*x%MOD;
        y>>=1;
    }
    return res;
}
int jc[N],nj[N];
int p[N],rt[N];
int tot,v[MAXK],s[MAXK][2];
int build(int p,int k,int l,int r){
    int x=++tot;
    v[x]=v[p]+1;s[x][0]=s[p][0];s[x][1]=s[p][1];
    if(l==r)return x;
    int m=l+r>>1;
    if(k<=m)s[x][0]=build(s[p][0],k,l,m);
    else s[x][1]=build(s[p][1],k,m+1,r);
    return x;
}
int find(int d,int u,int k,int l,int r){
    if(l==r)return l;
    int m=l+r>>1,c=v[s[u][0]]-v[s[d][0]];
    if(c>=k)return find(s[d][0],s[u][0],k,l,m);
    return find(s[d][1],s[u][1],k-c,m+1,r);
}
int get(int d,int u,int k,int l,int r){
    if(l==r)return v[u]-v[d];
    int m=l+r>>1;
    if(k<=m)return get(s[d][0],s[u][0],k,l,m);
    return v[s[u][0]]-v[s[d][0]]+get(s[d][1],s[u][1],k,m+1,r);
}
int main(){
    freopen("y.in","r",stdin);
    freopen("y.out","w",stdout);
    jc[0]=1;for(int i=1;i<N;i++)jc[i]=1ll*jc[i-1]*i%MOD;
    nj[N-1]=qpow(jc[N-1],MOD-2);for(int i=N-1;i;i--)nj[i-1]=1ll*nj[i]*i%MOD;
    int T=gi();
    while(T--){
        int n=gi(),m=gi();
        for(int i=1;i<=n;i++)rt[i]=build(rt[i-1],p[i]=gi(),1,n);
        while(m--){
            int l1=gi(),r1=gi(),l2=gi(),r2=gi(),S=r1-l1+1,ans=1;
            for(int I=0;I<S;){
                int A=get(rt[l1-1],rt[r1],find(rt[l2-1],rt[r2],I+1,1,n),1,n),
                    NI=(A==S?S:get(rt[l2-1],rt[r2],find(rt[l1-1],rt[r1],A+1,1,n),1,n));
                if(A-NI+1<=0)ans=0;
                else ans=1ll*ans*jc[A-I]%MOD*nj[A-NI]%MOD;
                I=NI;
            }
            printf("%d\n",ans);
        }
    }
    return 0;
}
