#include <cstdio>
#include <algorithm>
#include <vector>
#include <queue>

#define rep(i, x, y) for (int i = (x), _ = (y); i <= _; ++i)
#define down(i, x, y) for (int i = (x), _ = (y); i >= _; --i)
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define bin(x) (1<<(x))
//#define LX_JUDGE

using namespace std;
typedef long long LL;

template<typename T> inline void upmax(T &x, T y) { x < y ? x = y : 0; }
template<typename T> inline void upmin(T &x, T y) { x > y ? x = y : 0; }

template<typename T>
inline void read(T &x) {
	char c;
	while ((c = getchar()) < '0' || c > '9');
	for (x = c - '0'; (c = getchar()) >= '0' && c <= '9'; x = x * 10 + c - '0');
}

const int maxn = 1e5 + 10;
const int maxm = 1e7 + 10;

vector<int> adj[maxn];
int fa[maxn], val[maxn];

int bag[maxm];
int n, P;
LL ans;

inline int inmod(int x, int m) {
	if (x < 0)  x += m;
	if (x >= m) x -= m;
	return x;
}

struct Data {
	int x, sum, mx;
	Data() {}
	Data(int x, int sum, int mx) : x(x), sum(sum), mx(mx) {}
	inline bool operator < (const Data &b) const {
		return mx > b.mx;
	}
};

bool del[maxn];

LL calc(int root, int from) {
	static int sta[maxn], cnt;
	priority_queue<Data> que;
	int vr;
	if (from < 0) {
		vr = val[root];
		que.push(Data(root, 0, val[root]));
	} else {
		vr = from;
		que.push(Data(root, val[root] % P, max(from, val[root])));
	}
	LL res = 0;
	while (!que.empty()) {
		Data u = que.top();
		que.pop();
		res += bag[inmod((u.mx - vr - u.sum) % P, P)];
		sta[cnt++] = u.sum;
		bag[u.sum]++;
		for (int to : adj[u.x]) {
			if (to != fa[u.x] && !del[to]) {
				int t = val[to];
				que.push(Data(to, (u.sum + t) % P, max(u.mx, t)));
			}
		}
	}
	while (cnt) {
		bag[sta[--cnt]]--;
	}
	return res;
}

int size[maxn], nodeCnt;
int heavy, cent;

void getRoot(int x, int fa) {
	int mx = 0;
	size[x] = 1;
	for (int to : adj[x]) {
		if (to != fa && !del[to]) {
			getRoot(to, x);
			size[x] += size[to];
			upmax(mx, size[to]);
		}
	}
	upmax(mx, nodeCnt - size[x]);
	if (mx < heavy) {
		heavy = mx;
		cent = x;
	}
}

void dfs(int x) {
	size[x] = 1;
	for (int to : adj[x]) {
		if (to != fa[x] && !del[to]) {
			fa[to] = x;
			dfs(to);
			size[x] += size[to];
		}
	}
}

void solve(int x) {
	fa[x] = 0;
	dfs(x);
	ans += calc(x, -1);
	del[x] = 1;
	for (int to : adj[x]) {
		if (del[to]) continue ;
		ans -= calc(to, val[x]);
		nodeCnt = heavy = size[to];
		getRoot(to, x);
		solve(cent);
	}
}

void DC(int n) {
	nodeCnt = heavy = n;
	getRoot(1, 0);
	solve(cent);
}

int main() {
#ifdef LX_JUDGE
	freopen("in.txt", "r", stdin);
#endif
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	read(n), read(P);
	int x, y;
	rep (i, 1, n - 1) {
		read(x), read(y);
		adj[x].pb(y);
		adj[y].pb(x);
	}
	rep (i, 1, n) {
		read(val[i]);
	}
	DC(n);
	printf("%lld\n", ans + n);
	fclose(stdin);
	fclose(stdout);
    return 0;
}
