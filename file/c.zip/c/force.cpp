#include <cstdio>
#include <algorithm>
#include <vector>

#define rep(i, x, y) for (int i = (x), _ = (y); i <= _; ++i)
#define down(i, x, y) for (int i = (x), _ = (y); i >= _; --i)
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define bin(x) (1<<(x))
//#define LX_JUDGE

using namespace std;
typedef long long LL;
typedef pair<int, int> pii;

template<typename T> inline void upmax(T &x, T y) { x < y ? x = y : 0; }
template<typename T> inline void upmin(T &x, T y) { x > y ? x = y : 0; }

template<typename T>
inline void read(T &x) {
	char c;
	while ((c = getchar()) < '0' || c > '9');
	for (x = c - '0'; (c = getchar()) >= '0' && c <= '9'; x = x * 10 + c - '0');
}

const int inf = 0x3f3f3f3f;
const int N = 1e5 + 10;

vector<int> adj[N];
int val[N];
int n, P;
LL ans;

void dfs(int x, int fa, int s, int mx) { 
	s = (s + val[x]) % P;
	upmax(mx, val[x]);
	if (mx % P == s) {
		++ans;
	}
	for (int to : adj[x]) {
		if (to != fa) {
			dfs(to, x, s, mx);
		}
	}
}

int main() {
#ifdef LX_JUDGE
	freopen("in.txt", "r", stdin);
#endif
	read(n), read(P);
	int x, y;
	rep (i, 1, n - 1) {
		read(x), read(y);
		adj[x].pb(y);
		adj[y].pb(x);
	}
	rep (i, 1, n) {
		read(val[i]);
	}
	rep (i, 1, n) {
		dfs(i, 0, 0, 0);
	}
	printf("%lld\n", (ans + n) / 2);
	return 0;
}
