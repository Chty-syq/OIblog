#include <bits/stdc++.h>

#define rep(i, x, y) for (int i = (x), _ = (y); i <= _; ++i)
#define down(i, x, y) for (int i = (x), _ = (y); i >= _; --i)
#define x first
#define y second
#define mp make_pair
#define pb push_back
#define bin(x) (1<<(x))
#define LX_JUDGE

using namespace std;
typedef long long LL;
typedef pair<int, int> pii;

template<typename T> inline void upmax(T &x, T y) { x < y ? x = y : 0; }
template<typename T> inline void upmin(T &x, T y) { x > y ? x = y : 0; }

template<typename T>
inline void read(T &x) {
	char c;
	while ((c = getchar()) < '0' || c > '9');
	for (x = c - '0'; (c = getchar()) >= '0' && c <= '9'; x = x * 10 + c - '0');
}

const int inf = 0x3f3f3f3f;
const int N = 1e5 + 10;

int val[N], val2[N];
int id[N];

int main() {
//	freopen("in.txt", "w", stdout);
	srand((int) time(0));
	int M = 1e9, V = 5000000;
	int B = 90000, C = 10000;
	int n = B + rand() % C + 1;
	int P = rand() % V + 233666;
	printf("%d %d\n", n, P);
	rep (i, 1, n) id[i] = i;
	random_shuffle(id + 1, id + n + 1);
	rep (i, 2, n) {
		int v = min(rand() % 10 + 5, i - 1);
//		int v = i - 1;
//		int v = 1;
		int x = id[i - rand() % v - 1], y = id[i];
		if (rand() % 2) swap(x, y);
		printf("%d %d\n", x, y);
	}
	rep (i, 1, n) {
		val[i] = rand() % M + 1;
	}
	sort(val + 1, val + n + 1);
	int num = 75;
	rep (i, 1, num) {
		int x = rand() % n + 1, y = rand() % n + 1;
		swap(val[x], val[y]);
	}
	rep (i, 1, n) {
		val2[id[i]] = val[i];
	}
	rep (i, 1, n) {
		printf("%d ", val2[i]);
	}
	puts("");
	return 0;
}
